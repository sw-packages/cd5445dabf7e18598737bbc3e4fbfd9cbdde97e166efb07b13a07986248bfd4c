/// End a code block started by "ignore-deprecated-pre.hxx".
#pragma GCC diagnostic pop
